 import { Typography } from "@mui/material";
import Home from "./home/page";
import Register from "./register/page";
import Login from "./login/page";
export default function Page() {
  return (
    <>
   
      <Login />
    </>
  ); 
}
