import { Typography } from "@mui/material";
import Login from "./login/page";
export default function Page() {
    return (
        <>
            <Login />
        </>
    );
}
