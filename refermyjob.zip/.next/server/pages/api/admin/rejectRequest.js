"use strict";(()=>{var e={};e.id=6900,e.ids=[6900],e.modules={11185:e=>{e.exports=require("mongoose")},20145:e=>{e.exports=require("next/dist/compiled/next-server/pages-api.runtime.prod.js")},45184:e=>{e.exports=require("nodemailer")},56249:(e,t)=>{Object.defineProperty(t,"l",{enumerable:!0,get:function(){return function e(t,r){return r in t?t[r]:"then"in t&&"function"==typeof t.then?t.then(t=>e(t,r)):"function"==typeof t&&"default"===r?t:void 0}}})},10347:(e,t,r)=>{r.r(t),r.d(t,{config:()=>m,default:()=>p,routeModule:()=>f});var a={};r.r(a),r.d(a,{default:()=>c});var i=r(71802),s=r(47153),n=r(56249),o=r(85130),d=r(10746),l=r(82723),u=r(93452);async function c(e,t){let{method:r}=e;if(await (0,o.Z)(),"POST"!==r)return t.setHeader("Allow",["POST"]),t.status(405).end(`Method ${r} Not Allowed`);let{requestId:a,comment:i}=e.body;if(!a)return t.status(400).json({success:!1,msg:"Request ID is required"});try{let e=await d.Z.findById(a).populate("sender_id").populate("receiver_id");if(!e)return t.status(404).json({success:!1,msg:"Referral request not found"});if("Waiting"!==e.status)return t.status(400).json({success:!1,msg:`Referral request cannot be rejected as it is currently ${e.status.toLowerCase()}`});let r=e.sender_id,s=e.receiver_id,n=`
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Email Template</title>
            </head>
            <body style="font-family: Arial, sans-serif; line-height: 1.6;">
                <p>Hi ${s.first_name},</p>
                <p>Verification declined. Kindly submit relevant mail or screenshot to validate submission.</p>
                <p>Regards,</p>
                <p>RMJ</p>
            </body>
            </html>
        `,o=await (0,u.Z)({from:process.env.NEXT_GMAIL_USER,to:s.email,subject:"Verification Declined",text:n}),c=`
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Email Template</title>
            </head>
            <body style="font-family: Arial, sans-serif; line-height: 1.6;">
                <p>Hi ${r.first_name},</p>
                <p>Verification in progress. We will confirm once the request is complete.</p>
                <p>Regards,</p>
                <p>RMJ</p>
            </body>
            </html>
        `,p=await (0,u.Z)({from:process.env.NEXT_GMAIL_USER,to:r.email,subject:"Verification In Progress",text:c});if(!o||!p)return t.status(500).json({success:!1,msg:"Emails could not be sent"});{e.status="Waiting",e.verification=!1,e.comment=i,await e.save();let r=await l.Z.findOne({request_id:a});return r&&(r.verified=!1,await r.save()),t.status(200).json({success:!0,msg:"Referral request verification rejected and awaiting new submission"})}}catch(e){return t.status(500).json({success:!1,msg:e.message})}}let p=(0,n.l)(a,"default"),m=(0,n.l)(a,"config"),f=new i.PagesAPIRouteModule({definition:{kind:s.x.PAGES_API,page:"/api/admin/rejectRequest",pathname:"/api/admin/rejectRequest",bundlePath:"",filename:""},userland:a})},85130:(e,t,r)=>{r.d(t,{Z:()=>n});var a=r(11185),i=r.n(a);let s=!1,n=async()=>{if(s){console.log("Using cached database connection.");return}try{let e=await i().connect("mongodb+srv://rmjtest98:RMJtest123!@cluster0.itndc7z.mongodb.net/refermyjob");s=e.connections[0].readyState,console.log(`Database connected successfully to ${e.connection.host}`)}catch(e){throw console.error("Error connecting to the database:",e.message),Error("Database connection failed")}}},93452:(e,t,r)=>{r.d(t,{Z:()=>s});var a=r(45184),i=r.n(a);let s=async({from:e,to:t,subject:r,text:a,html:s})=>{let n=i().createTransport({service:"gmail",auth:{user:process.env.NEXT_GMAIL_USER,pass:process.env.NEXT_GMAIL_PASS}}),o=await n.sendMail({from:`"ReferMyJob" <${e}>`,to:t,subject:r,text:a,html:s||a});return console.log("Message sent: %s",o.messageId),o}},10746:(e,t,r)=>{r.d(t,{Z:()=>n});var a=r(11185),i=r.n(a);r(87778);let s=new(i()).Schema({sender_id:{type:i().Schema.Types.ObjectId,ref:"Users",required:!0},receiver_id:{type:i().Schema.Types.ObjectId,ref:"Users",required:!0},request_id:{type:String,required:!0},status:{type:String,enum:["Accepted","Rejected","Successful","Expired","Waiting","Canceled","Send"]},verification:{type:Boolean,default:!1},vacancy_name:{type:String,required:!0,default:""},job_id:{type:String,required:!0,default:""},job_link:{type:String,required:!0,default:""},expireOn:{type:Date,required:!0,default:()=>new Date(Date.now()+2592e5)},expired:{type:Boolean,default:!1},comment:{type:String,default:""},refer_points:{type:Number,default:0},isDeleted:{type:Boolean,default:!1}},{timestamps:!0});s.pre("save",function(e){this.expireOn||(this.expireOn=new Date(Date.now()+2592e5)),e()}),s.statics.expireRequests=async function(){for(let e of(await this.find({createdAt:{$lt:new Date(Date.now()-2592e5)},status:{$in:["Send","Accepted","Waiting"]}}).populate("sender_id").populate("receiver_id"))){e.status="Expired",e.expired=!0,await e.save();let t=e.sender_id;t.total_refer_points+=1,await t.save();let r=new ReferPointsDetails({user_id:t._id,type:"credit",credited:!0,debited:!1,refer_points:1,message:"Referral request expired and points credited back",total_refer_points:t.total_refer_points});await r.save();let a=new PointsTransactionsDetails({user_id:t._id,refer_details_id:r._id,type:"credit",credited:!0,debited:!1,refer_points:1,amount:"0",message:"Referral request expired and points credited back",TXN_ID:e._id});await a.save();let i=`
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Email Template</title>
            </head>
            <body style="font-family: Arial, sans-serif; line-height: 1.6;">
                <p>Hi ${t.first_name},</p>
                <p>Your referral request has expired. The referral point has been credited back to your account.</p>
                <p>Regards,</p>
                <p>RMJ</p>
            </body>
            </html>
        `;await sendEmail({from:process.env.NEXT_GMAIL_USER,to:t.email,subject:"Referral Request Expired",text:i});let s=e.receiver_id,n=`
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Email Template</title>
            </head>
            <body style="font-family: Arial, sans-serif; line-height: 1.6;">
                <p>Hi ${s.first_name},</p>
                <p>The referral request sent to you has expired. Please check the referral requests in your account for more details.</p>
                <p>Regards,</p>
                <p>RMJ</p>
            </body>
            </html>
        `;await sendEmail({from:process.env.NEXT_GMAIL_USER,to:s.email,subject:"Referral Request Expired",text:n})}};let n=i().models.RefferalRequast||i().model("RefferalRequast",s)},82723:(e,t,r)=>{r.d(t,{Z:()=>n});var a=r(11185),i=r.n(a);r(10746);let s=new(i()).Schema({request_id:{type:i().Schema.Types.ObjectId,ref:"RefferalRequast",required:!0},attachment:{type:[String],validate:[function(e){return e.length<=5},"Cannot exceed 5 photos"]},verified:{type:Boolean,default:!1},remark:{type:String,default:""},isDeleted:{type:Boolean,default:!1}},{timestamps:!0}),n=i().models.RequestVerification||i().model("RequestVerification",s)},87778:(e,t,r)=>{r.d(t,{Z:()=>n});var a=r(11185),i=r.n(a);let s=new(i()).Schema({first_name:{type:String,required:[!1,"Please provide first name"],maxlength:[60,"First name cannot be more than 60 characters"]},last_name:{type:String,required:[!1,"Please provide last name"],maxlength:[60,"Last name cannot be more than 60 characters"]},email:{type:String,required:[!1,"Please provide email"],unique:!0,match:[/^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/,"Please provide a valid email address"]},emailVerified:{type:Boolean,default:!1},email_otp:{type:String,required:!1,default:""},password:{type:String,required:[!1,"Please provide password"],minlength:[8,"Password must be at least 8 characters long"]},phone_number:{type:String,validate:{validator:function(e){return""===e||/^\d{10}$/.test(e)},message:e=>`${e.value} is not a valid phone number! It should be exactly 10 digits.`},default:""},currentCompanyName:{type:String,trim:!0,lowercase:!0,required:[!1,"Please provide current comapany"],default:""},currentCompanyEmail:{type:String,trim:!0,lowercase:!0,validate(e){if(e&&!/^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/.test(e))throw Error("Invalid company email address")},default:""},current_location:{type:String,required:[!1,"Please provide current location"]},position:{type:String,trim:!0,default:""},graduationCollege:{type:String,required:[!1,"Please provide graduation college"],default:"N/A"},postGradCollege:{type:String,required:[!1,"Please provide post graduation college"],default:"N/A"},degree:{type:String,required:[!1,"Please provide degree"]},sector:{type:String,required:[!1,"Please provide sector"],trim:!0},upi_id:{type:String,default:""},signup_type:{type:String,required:[!0,"Please provide signup type"],enum:["normal","google","linkedin"],default:"normal"},total_refer_points:{type:Number,default:0},resetPasswordToken:{type:String,required:!1},resetPasswordExpires:{type:Date,required:!1},isDeleted:{type:Boolean,default:!1}},{timestamps:!0}),n=i().models.Users||i().model("Users",s)},47153:(e,t)=>{var r;Object.defineProperty(t,"x",{enumerable:!0,get:function(){return r}}),function(e){e.PAGES="PAGES",e.PAGES_API="PAGES_API",e.APP_PAGE="APP_PAGE",e.APP_ROUTE="APP_ROUTE"}(r||(r={}))},71802:(e,t,r)=>{e.exports=r(20145)}};var t=require("../../../webpack-api-runtime.js");t.C(e);var r=t(t.s=10347);module.exports=r})();