"use strict";(()=>{var e={};e.id=9527,e.ids=[9527],e.modules={11185:e=>{e.exports=require("mongoose")},20145:e=>{e.exports=require("next/dist/compiled/next-server/pages-api.runtime.prod.js")},45184:e=>{e.exports=require("nodemailer")},56249:(e,t)=>{Object.defineProperty(t,"l",{enumerable:!0,get:function(){return function e(t,r){return r in t?t[r]:"then"in t&&"function"==typeof t.then?t.then(t=>e(t,r)):"function"==typeof t&&"default"===r?t:void 0}}})},28047:(e,t,r)=>{r.r(t),r.d(t,{config:()=>y,default:()=>f,routeModule:()=>g});var i={};r.r(i),r.d(i,{default:()=>m});var a=r(71802),s=r(47153),n=r(56249),d=r(85130),o=r(10746),l=r(42828),p=r(19377),u=r(82723),c=r(93452);async function m(e,t){let{method:r}=e;if(await (0,d.Z)(),"POST"!==r)return t.setHeader("Allow",["POST"]),t.status(405).end(`Method ${r} Not Allowed`);let{requestId:i}=e.body;if(!i)return t.status(400).json({success:!1,msg:"Request ID is required"});try{let e=await o.Z.findById(i).populate("sender_id").populate("receiver_id");if(!e)return t.status(404).json({success:!1,msg:"Referral request not found"});if("Waiting"!==e.status)return t.status(400).json({success:!1,msg:`Referral request cannot be accepted as it is currently ${e.status.toLowerCase()}`});let r=e.sender_id,a=e.receiver_id,s=`
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Email Template</title>
            </head>
            <body style="font-family: Arial, sans-serif; line-height: 1.6;">
                <p>Hi ${a.first_name},</p>
                <p>Verification complete. Refer point credited. Thank you for your efforts.</p>
                <p>Regards,</p>
                <p>RMJ</p>
            </body>
            </html>
        `,n=await (0,c.Z)({from:process.env.NEXT_GMAIL_USER,to:a.email,subject:"Verification Complete",text:s}),d=`
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Email Template</title>
            </head>
            <body style="font-family: Arial, sans-serif; line-height: 1.6;">
                <p>Hi ${r.first_name},</p>
                <p>Your referral has been successfully submitted by User ${a.first_name}.</p>
                <p>Regards,</p>
                <p>RMJ</p>
            </body>
            </html>
        `,m=await (0,c.Z)({from:process.env.NEXT_GMAIL_USER,to:r.email,subject:"Referral Successfully Submitted",text:d});if(!n||!m)return t.status(500).json({success:!1,msg:"Emails could not be sent"});{e.status="Successful",e.verification=!0,await e.save();let r=await u.Z.findOne({request_id:i});r&&(r.verified=!0,await r.save()),a.total_refer_points+=1,await a.save();let s=new l.Z({user_id:a._id,type:"credit",credited:!0,debited:!1,refer_points:1,message:"Verification complete and points credited",total_refer_points:a.total_refer_points});await s.save();let n=new p.Z({user_id:a._id,refer_details_id:s._id,type:"credit",credited:!0,debited:!1,refer_points:1,amount:"0",message:"Verification complete and points credited",TXN_ID:e._id});return await n.save(),t.status(200).json({success:!0,msg:"Referral request accepted and points credited"})}}catch(e){return t.status(500).json({success:!1,msg:e.message})}}let f=(0,n.l)(i,"default"),y=(0,n.l)(i,"config"),g=new a.PagesAPIRouteModule({definition:{kind:s.x.PAGES_API,page:"/api/admin/acceptRequest",pathname:"/api/admin/acceptRequest",bundlePath:"",filename:""},userland:i})},85130:(e,t,r)=>{r.d(t,{Z:()=>n});var i=r(11185),a=r.n(i);let s=!1,n=async()=>{if(s){console.log("Using cached database connection.");return}try{let e=await a().connect("mongodb+srv://rmjtest98:RMJtest123!@cluster0.itndc7z.mongodb.net/refermyjob");s=e.connections[0].readyState,console.log(`Database connected successfully to ${e.connection.host}`)}catch(e){throw console.error("Error connecting to the database:",e.message),Error("Database connection failed")}}},93452:(e,t,r)=>{r.d(t,{Z:()=>s});var i=r(45184),a=r.n(i);let s=async({from:e,to:t,subject:r,text:i,html:s})=>{let n=a().createTransport({service:"gmail",auth:{user:process.env.NEXT_GMAIL_USER,pass:process.env.NEXT_GMAIL_PASS}}),d=await n.sendMail({from:`"ReferMyJob" <${e}>`,to:t,subject:r,text:i,html:s||i});return console.log("Message sent: %s",d.messageId),d}},19377:(e,t,r)=>{r.d(t,{Z:()=>n});var i=r(11185),a=r.n(i);r(87778),r(42828);let s=new(a()).Schema({user_id:{type:a().Schema.Types.ObjectId,ref:"Users",required:!0},refer_details_id:{type:a().Schema.Types.ObjectId,ref:"ReferPointsDetails",required:!0},type:{type:String,required:[!0,"Please provide valid type"],enum:["credit","debit"],required:!0},credited:{type:Boolean,required:!0},debited:{type:Boolean,required:!0},refer_points:{type:Number,default:0,required:!0},amount:{type:String,default:"0"},message:{type:String,default:""},TXN_ID:{type:String,unique:!0,required:!0},isDeleted:{type:Boolean,default:!1}},{timestamps:!0}),n=a().models.PointsTransactionsDetails||a().model("PointsTransactionsDetails",s)},42828:(e,t,r)=>{r.d(t,{Z:()=>n});var i=r(11185),a=r.n(i);r(87778);let s=new(a()).Schema({user_id:{type:a().Schema.Types.ObjectId,ref:"Users",required:!0},type:{type:String,required:[!0,"Please provide valid type"],enum:["credit","debit"],required:!0},credited:{type:Boolean,required:!0},debited:{type:Boolean,required:!0},refer_points:{type:Number,default:0,required:!0},message:{type:String,default:""},total_refer_points:{type:Number},isDeleted:{type:Boolean,default:!1}},{timestamps:!0}),n=a().models.ReferPointsDetails||a().model("ReferPointsDetails",s)},10746:(e,t,r)=>{r.d(t,{Z:()=>n});var i=r(11185),a=r.n(i);r(87778);let s=new(a()).Schema({sender_id:{type:a().Schema.Types.ObjectId,ref:"Users",required:!0},receiver_id:{type:a().Schema.Types.ObjectId,ref:"Users",required:!0},request_id:{type:String,required:!0},status:{type:String,enum:["Accepted","Rejected","Successful","Expired","Waiting","Canceled","Send"]},verification:{type:Boolean,default:!1},vacancy_name:{type:String,required:!0,default:""},job_id:{type:String,required:!0,default:""},job_link:{type:String,required:!0,default:""},expireOn:{type:Date,required:!0,default:()=>new Date(Date.now()+2592e5)},expired:{type:Boolean,default:!1},comment:{type:String,default:""},refer_points:{type:Number,default:0},isDeleted:{type:Boolean,default:!1}},{timestamps:!0});s.pre("save",function(e){this.expireOn||(this.expireOn=new Date(Date.now()+2592e5)),e()}),s.statics.expireRequests=async function(){for(let e of(await this.find({createdAt:{$lt:new Date(Date.now()-2592e5)},status:{$in:["Send","Accepted","Waiting"]}}).populate("sender_id").populate("receiver_id"))){e.status="Expired",e.expired=!0,await e.save();let t=e.sender_id;t.total_refer_points+=1,await t.save();let r=new ReferPointsDetails({user_id:t._id,type:"credit",credited:!0,debited:!1,refer_points:1,message:"Referral request expired and points credited back",total_refer_points:t.total_refer_points});await r.save();let i=new PointsTransactionsDetails({user_id:t._id,refer_details_id:r._id,type:"credit",credited:!0,debited:!1,refer_points:1,amount:"0",message:"Referral request expired and points credited back",TXN_ID:e._id});await i.save();let a=`
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Email Template</title>
            </head>
            <body style="font-family: Arial, sans-serif; line-height: 1.6;">
                <p>Hi ${t.first_name},</p>
                <p>Your referral request has expired. The referral point has been credited back to your account.</p>
                <p>Regards,</p>
                <p>RMJ</p>
            </body>
            </html>
        `;await sendEmail({from:process.env.NEXT_GMAIL_USER,to:t.email,subject:"Referral Request Expired",text:a});let s=e.receiver_id,n=`
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Email Template</title>
            </head>
            <body style="font-family: Arial, sans-serif; line-height: 1.6;">
                <p>Hi ${s.first_name},</p>
                <p>The referral request sent to you has expired. Please check the referral requests in your account for more details.</p>
                <p>Regards,</p>
                <p>RMJ</p>
            </body>
            </html>
        `;await sendEmail({from:process.env.NEXT_GMAIL_USER,to:s.email,subject:"Referral Request Expired",text:n})}};let n=a().models.RefferalRequast||a().model("RefferalRequast",s)},82723:(e,t,r)=>{r.d(t,{Z:()=>n});var i=r(11185),a=r.n(i);r(10746);let s=new(a()).Schema({request_id:{type:a().Schema.Types.ObjectId,ref:"RefferalRequast",required:!0},attachment:{type:[String],validate:[function(e){return e.length<=5},"Cannot exceed 5 photos"]},verified:{type:Boolean,default:!1},remark:{type:String,default:""},isDeleted:{type:Boolean,default:!1}},{timestamps:!0}),n=a().models.RequestVerification||a().model("RequestVerification",s)},87778:(e,t,r)=>{r.d(t,{Z:()=>n});var i=r(11185),a=r.n(i);let s=new(a()).Schema({first_name:{type:String,required:[!1,"Please provide first name"],maxlength:[60,"First name cannot be more than 60 characters"]},last_name:{type:String,required:[!1,"Please provide last name"],maxlength:[60,"Last name cannot be more than 60 characters"]},email:{type:String,required:[!1,"Please provide email"],unique:!0,match:[/^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/,"Please provide a valid email address"]},emailVerified:{type:Boolean,default:!1},email_otp:{type:String,required:!1,default:""},password:{type:String,required:[!1,"Please provide password"],minlength:[8,"Password must be at least 8 characters long"]},phone_number:{type:String,validate:{validator:function(e){return""===e||/^\d{10}$/.test(e)},message:e=>`${e.value} is not a valid phone number! It should be exactly 10 digits.`},default:""},currentCompanyName:{type:String,trim:!0,lowercase:!0,required:[!1,"Please provide current comapany"],default:""},currentCompanyEmail:{type:String,trim:!0,lowercase:!0,validate(e){if(e&&!/^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/.test(e))throw Error("Invalid company email address")},default:""},current_location:{type:String,required:[!1,"Please provide current location"]},position:{type:String,trim:!0,default:""},graduationCollege:{type:String,required:[!1,"Please provide graduation college"],default:"N/A"},postGradCollege:{type:String,required:[!1,"Please provide post graduation college"],default:"N/A"},degree:{type:String,required:[!1,"Please provide degree"]},sector:{type:String,required:[!1,"Please provide sector"],trim:!0},upi_id:{type:String,default:""},signup_type:{type:String,required:[!0,"Please provide signup type"],enum:["normal","google","linkedin"],default:"normal"},total_refer_points:{type:Number,default:0},resetPasswordToken:{type:String,required:!1},resetPasswordExpires:{type:Date,required:!1},isDeleted:{type:Boolean,default:!1}},{timestamps:!0}),n=a().models.Users||a().model("Users",s)},47153:(e,t)=>{var r;Object.defineProperty(t,"x",{enumerable:!0,get:function(){return r}}),function(e){e.PAGES="PAGES",e.PAGES_API="PAGES_API",e.APP_PAGE="APP_PAGE",e.APP_ROUTE="APP_ROUTE"}(r||(r={}))},71802:(e,t,r)=>{e.exports=r(20145)}};var t=require("../../../webpack-api-runtime.js");t.C(e);var r=t(t.s=28047);module.exports=r})();