"use strict";(()=>{var e={};e.id=6101,e.ids=[6101],e.modules={11185:e=>{e.exports=require("mongoose")},20145:e=>{e.exports=require("next/dist/compiled/next-server/pages-api.runtime.prod.js")},45184:e=>{e.exports=require("nodemailer")},46555:e=>{e.exports=import("uuid")},56249:(e,t)=>{Object.defineProperty(t,"l",{enumerable:!0,get:function(){return function e(t,r){return r in t?t[r]:"then"in t&&"function"==typeof t.then?t.then(t=>e(t,r)):"function"==typeof t&&"default"===r?t:void 0}}})},8964:(e,t,r)=>{r.a(e,async(e,a)=>{try{r.r(t),r.d(t,{config:()=>p,default:()=>l,routeModule:()=>u});var i=r(71802),n=r(47153),s=r(56249),o=r(95786),d=e([o]);o=(d.then?(await d)():d)[0];let l=(0,s.l)(o,"default"),p=(0,s.l)(o,"config"),u=new i.PagesAPIRouteModule({definition:{kind:n.x.PAGES_API,page:"/api/send-request",pathname:"/api/send-request",bundlePath:"",filename:""},userland:o});a()}catch(e){a(e)}})},85130:(e,t,r)=>{r.d(t,{Z:()=>s});var a=r(11185),i=r.n(a);let n=!1,s=async()=>{if(n){console.log("Using cached database connection.");return}try{let e=await i().connect("mongodb+srv://rmjtest98:RMJtest123!@cluster0.itndc7z.mongodb.net/refermyjob");n=e.connections[0].readyState,console.log(`Database connected successfully to ${e.connection.host}`)}catch(e){throw console.error("Error connecting to the database:",e.message),Error("Database connection failed")}}},93452:(e,t,r)=>{r.d(t,{Z:()=>n});var a=r(45184),i=r.n(a);let n=async({from:e,to:t,subject:r,text:a,html:n})=>{let s=i().createTransport({service:"gmail",auth:{user:process.env.NEXT_GMAIL_USER,pass:process.env.NEXT_GMAIL_PASS}}),o=await s.sendMail({from:`"ReferMyJob" <${e}>`,to:t,subject:r,text:a,html:n||a});return console.log("Message sent: %s",o.messageId),o}},19377:(e,t,r)=>{r.d(t,{Z:()=>s});var a=r(11185),i=r.n(a);r(87778),r(42828);let n=new(i()).Schema({user_id:{type:i().Schema.Types.ObjectId,ref:"Users",required:!0},refer_details_id:{type:i().Schema.Types.ObjectId,ref:"ReferPointsDetails",required:!0},type:{type:String,required:[!0,"Please provide valid type"],enum:["credit","debit"],required:!0},credited:{type:Boolean,required:!0},debited:{type:Boolean,required:!0},refer_points:{type:Number,default:0,required:!0},amount:{type:String,default:"0"},message:{type:String,default:""},TXN_ID:{type:String,unique:!0,required:!0},isDeleted:{type:Boolean,default:!1}},{timestamps:!0}),s=i().models.PointsTransactionsDetails||i().model("PointsTransactionsDetails",n)},42828:(e,t,r)=>{r.d(t,{Z:()=>s});var a=r(11185),i=r.n(a);r(87778);let n=new(i()).Schema({user_id:{type:i().Schema.Types.ObjectId,ref:"Users",required:!0},type:{type:String,required:[!0,"Please provide valid type"],enum:["credit","debit"],required:!0},credited:{type:Boolean,required:!0},debited:{type:Boolean,required:!0},refer_points:{type:Number,default:0,required:!0},message:{type:String,default:""},total_refer_points:{type:Number},isDeleted:{type:Boolean,default:!1}},{timestamps:!0}),s=i().models.ReferPointsDetails||i().model("ReferPointsDetails",n)},10746:(e,t,r)=>{r.d(t,{Z:()=>s});var a=r(11185),i=r.n(a);r(87778);let n=new(i()).Schema({sender_id:{type:i().Schema.Types.ObjectId,ref:"Users",required:!0},receiver_id:{type:i().Schema.Types.ObjectId,ref:"Users",required:!0},request_id:{type:String,required:!0},status:{type:String,enum:["Accepted","Rejected","Successful","Expired","Waiting","Canceled","Send"]},verification:{type:Boolean,default:!1},vacancy_name:{type:String,required:!0,default:""},job_id:{type:String,required:!0,default:""},job_link:{type:String,required:!0,default:""},expireOn:{type:Date,required:!0,default:()=>new Date(Date.now()+2592e5)},expired:{type:Boolean,default:!1},comment:{type:String,default:""},refer_points:{type:Number,default:0},isDeleted:{type:Boolean,default:!1}},{timestamps:!0});n.pre("save",function(e){this.expireOn||(this.expireOn=new Date(Date.now()+2592e5)),e()}),n.statics.expireRequests=async function(){for(let e of(await this.find({createdAt:{$lt:new Date(Date.now()-2592e5)},status:{$in:["Send","Accepted","Waiting"]}}).populate("sender_id").populate("receiver_id"))){e.status="Expired",e.expired=!0,await e.save();let t=e.sender_id;t.total_refer_points+=1,await t.save();let r=new ReferPointsDetails({user_id:t._id,type:"credit",credited:!0,debited:!1,refer_points:1,message:"Referral request expired and points credited back",total_refer_points:t.total_refer_points});await r.save();let a=new PointsTransactionsDetails({user_id:t._id,refer_details_id:r._id,type:"credit",credited:!0,debited:!1,refer_points:1,amount:"0",message:"Referral request expired and points credited back",TXN_ID:e._id});await a.save();let i=`
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Email Template</title>
            </head>
            <body style="font-family: Arial, sans-serif; line-height: 1.6;">
                <p>Hi ${t.first_name},</p>
                <p>Your referral request has expired. The referral point has been credited back to your account.</p>
                <p>Regards,</p>
                <p>RMJ</p>
            </body>
            </html>
        `;await sendEmail({from:process.env.NEXT_GMAIL_USER,to:t.email,subject:"Referral Request Expired",text:i});let n=e.receiver_id,s=`
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Email Template</title>
            </head>
            <body style="font-family: Arial, sans-serif; line-height: 1.6;">
                <p>Hi ${n.first_name},</p>
                <p>The referral request sent to you has expired. Please check the referral requests in your account for more details.</p>
                <p>Regards,</p>
                <p>RMJ</p>
            </body>
            </html>
        `;await sendEmail({from:process.env.NEXT_GMAIL_USER,to:n.email,subject:"Referral Request Expired",text:s})}};let s=i().models.RefferalRequast||i().model("RefferalRequast",n)},87778:(e,t,r)=>{r.d(t,{Z:()=>s});var a=r(11185),i=r.n(a);let n=new(i()).Schema({first_name:{type:String,required:[!1,"Please provide first name"],maxlength:[60,"First name cannot be more than 60 characters"]},last_name:{type:String,required:[!1,"Please provide last name"],maxlength:[60,"Last name cannot be more than 60 characters"]},email:{type:String,required:[!1,"Please provide email"],unique:!0,match:[/^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/,"Please provide a valid email address"]},emailVerified:{type:Boolean,default:!1},email_otp:{type:String,required:!1,default:""},password:{type:String,required:[!1,"Please provide password"],minlength:[8,"Password must be at least 8 characters long"]},phone_number:{type:String,validate:{validator:function(e){return""===e||/^\d{10}$/.test(e)},message:e=>`${e.value} is not a valid phone number! It should be exactly 10 digits.`},default:""},currentCompanyName:{type:String,trim:!0,lowercase:!0,required:[!1,"Please provide current comapany"],default:""},currentCompanyEmail:{type:String,trim:!0,lowercase:!0,validate(e){if(e&&!/^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/.test(e))throw Error("Invalid company email address")},default:""},current_location:{type:String,required:[!1,"Please provide current location"]},position:{type:String,trim:!0,default:""},graduationCollege:{type:String,required:[!1,"Please provide graduation college"],default:"N/A"},postGradCollege:{type:String,required:[!1,"Please provide post graduation college"],default:"N/A"},degree:{type:String,required:[!1,"Please provide degree"]},sector:{type:String,required:[!1,"Please provide sector"],trim:!0},upi_id:{type:String,default:""},signup_type:{type:String,required:[!0,"Please provide signup type"],enum:["normal","google","linkedin"],default:"normal"},total_refer_points:{type:Number,default:0},resetPasswordToken:{type:String,required:!1},resetPasswordExpires:{type:Date,required:!1},isDeleted:{type:Boolean,default:!1}},{timestamps:!0}),s=i().models.Users||i().model("Users",n)},95786:(e,t,r)=>{r.a(e,async(e,a)=>{try{r.r(t),r.d(t,{default:()=>c});var i=r(93452),n=r(85130),s=r(10746),o=r(42828),d=r(19377),l=r(87778),p=r(46555),u=e([p]);async function c(e,t){if("POST"===e.method){await (0,n.Z)();let{user_id:r,sender_id:a,sender_email:u,email:c,vacancy_name:m,first_name:f,last_name:y,job_id:g,job_link:h,receiver_first_name:_}=e.body,v=`
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Email Template</title>
        </head>
        <body style="font-family: Arial, sans-serif; line-height: 1.6;">
            <p>Hi ${_},</p>
    
            <p>Greetings from ReferMyJob.</p>
    
            <p>You’ve received a job refer request from <strong>${f} ${y}</strong> for <strong>${m}</strong> vacancy available in your company.</p>
            
            <p>Please accept or reject the request in the application.</p>

            <p>Job Id :- ${g}.</p>

            <p>Job Link :- ${h}.</p>

            <p>
                <a href="http://localhost:3000/requests-received" style="background-color: #4CAF50; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">Accept</a>
                <a href="http://localhost:3000/requests-received" style="background-color: #f44336; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">Reject</a>
            </p>
    
            <p>Regards,</p>
            <p>RMJ</p>
        </body>
        </html>
    `;try{if(await (0,i.Z)({from:u,to:c,subject:`Job Application Request For ${f} ${y}`,text:v})){let e=await l.Z.findById(r);if(!e)return t.status(404).json({msg:"Sender not found."});if(e.total_refer_points<1)return t.status(400).json({msg:"Insufficient refer points."});e.total_refer_points-=1,await e.save();let i=new s.Z({sender_id:r,receiver_id:a,request_id:(0,p.v4)(),status:"Send",vacancy_name:m,job_id:g,job_link:h,refer_points:1});await i.save();let n=new o.Z({user_id:r,type:"debit",credited:!1,debited:!0,refer_points:1,message:`Referral request for ${m}`,total_refer_points:e.total_refer_points});await n.save();let u=new d.Z({user_id:r,refer_details_id:n._id,type:"debit",credited:!1,debited:!0,refer_points:1,amount:"0",message:`Referral request for ${m}`,TXN_ID:(0,p.v4)()});return await u.save(),t.status(200).json({msg:"Email sent and referral recorded."})}}catch(e){return console.log(e,"error"),t.status(500).json({msg:"Email could not be sent."})}}else t.setHeader("Allow",["POST"]),t.status(405).end(`Method ${e.method} Not Allowed`)}p=(u.then?(await u)():u)[0],a()}catch(e){a(e)}})},47153:(e,t)=>{var r;Object.defineProperty(t,"x",{enumerable:!0,get:function(){return r}}),function(e){e.PAGES="PAGES",e.PAGES_API="PAGES_API",e.APP_PAGE="APP_PAGE",e.APP_ROUTE="APP_ROUTE"}(r||(r={}))},71802:(e,t,r)=>{e.exports=r(20145)}};var t=require("../../webpack-api-runtime.js");t.C(e);var r=t(t.s=8964);module.exports=r})();